/*
 * MarkovProcessAnalytic.cpp
 *
 *  Created on: 2 avr. 2018
 *      Author: Oussama BATATA
 */

#include "MarkovProcessAnalytic.h"


#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include "InputData.h"
#include "Caregiver.h"
#include "caregiversPopulation.h"
#include "RespiteService.h"

using namespace std;

namespace mySpace {


//je vais cr�er un vecteur pour stocker les valeurs mise � jours de l'�puisement des aiadnts

vector< vector < vector <float> > > burnoutTemp;
vector< vector< vector <float> > > respiteTemp;
//-----------------------------------------------------Fonction principales----------------------------------

//-----------------------------------------------------Debut----------------------------------

void MarkovProcessAnalytic::generateInstance(){

	this->_timeMaxRespite = this->_inputData->getmaxTimeInRespite();
	this->_burnoutMatrix = this->_inputData->getBurnoutMatrix();
	this->_respiteFrequence = this->_inputData->getRespiteFrequence();
	   this->generateVectorRespiteFrequence();
	//if(this->_respiteFrequence > 0){
		this->generateRespiteMatrix();
		this->adaptBurnoutMatrix();
	//}
   this->genrateBurnoutRepartition();
   this->generateRespiteRepartition();
}
//-----------------------------------------------------Fin----------------------------------

//-----------------------------------------------------Debut----------------------------------

void MarkovProcessAnalytic::adaptBurnoutMatrix(){

	for (unsigned int i = 0; i < this->_burnoutMatrix.size(); i++){
		for(unsigned int j = 0; j < this->_burnoutMatrix[i].size(); j++){
			for(unsigned int k =0; k < this->_burnoutMatrix[i][j].size(); k++){
				for(unsigned int l = 0; l < this->_burnoutMatrix[i][j][k].size(); l++){

					if(j == this->_burnoutMatrix[i].size() -1){
						this->_burnoutMatrix[i][j][k][l] = 0;
					}
					else{
						this->_burnoutMatrix[i][j][k][l]-= this->_burnoutMatrix[i][j][k][l]*this->_respiteFrequenceVector[i][k]*(this->_timeMaxRespite*(k+1));
					}
				}
			}
		}
	}
}
//-----------------------------------------------------Fin----------------------------------


//-----------------------------------------------------Debut----------------------------------

void MarkovProcessAnalytic::generateRespiteMatrix(){
	for (unsigned int i = 0; i < this->_burnoutMatrix.size(); i++){// boucle sur les clusters
		vector< vector < vector<float> > >temp; //vector temporaire pour stocker les donne�s
		for(unsigned int j = 0; j < this->_burnoutMatrix[i].size(); j++){//boucle sur le temps
			vector < vector<float> >temp1; //un autre vector temp pour stocker les donn�es
			for(unsigned int k = 0; k < this->_burnoutMatrix[i][j].size(); k++){//boucle sur le nbr d'�tats d�puisement
				vector<float> temp2; // le dernier vector enfin
				for(unsigned int b = 0; b <this->_timeMaxRespite; b++){
					for(unsigned int l = 0; l < this->_burnoutMatrix[i][j].size(); l++){
						if (l <= k){
							if (j == this->_burnoutMatrix[i].size()-1){
								temp2.push_back(float(1)/float((k+1)*(this->_timeMaxRespite)));
							}
							else{
								temp2.push_back(this->_respiteFrequenceVector[i][k]);
							}
						  }

					}
				}
               temp1.push_back(temp2);
			}
			temp.push_back(temp1);
		}
     this->_respiteMatrix.push_back(temp);
	}
}


//-----------------------------------------------------Fin----------------------------------

//-----------------------------------------------------Debut----------------------------------

void MarkovProcessAnalytic::printInstance(){

	cout<<"le temps max d'un soin de r�pit : "<<this->_timeMaxRespite<<endl;
	cout<<"la fr�quence de r�pit est : "<<this->_respiteFrequence<<endl;
   cout<<"------------------------------------------------------------------------"<<endl;
   cout<<"la matrice du burnout est la suivante : "<<endl;
   cout<<"------------------------------------------------------------------------"<<endl;
	for (unsigned int i = 0; i < this->_burnoutMatrix.size(); i++){// boucle sur les clusters
		for(unsigned int j = 0; j < this->_burnoutMatrix[i].size(); j++){//boucle sur le temps
			for(unsigned int k = 0; k < this->_burnoutMatrix[i][j].size(); k++){//boucle sur le nbr d'�tats d�puisement
				for(unsigned int l = 0; l < this->_burnoutMatrix[i][j][k].size(); l++){
                   cout<<this->_burnoutMatrix[i][j][k][l]<<" ";
				    }
				cout<<endl;
				}
		       cout<<"-----------------time-------------time"<<endl;
			}
		cout<<" ######################  cluster ####################################"<<endl;
		}


	   cout<<"------------------------------------------------------------------------"<<endl;
	   cout<<"la matrice du r�pit est la suivante : "<<endl;
	   cout<<"------------------------------------------------------------------------"<<endl;
	for (unsigned int i = 0; i < this->_respiteMatrix.size(); i++){// boucle sur les clusters
		for(unsigned int j = 0; j < this->_respiteMatrix[i].size(); j++){//boucle sur le temps
			for(unsigned int k = 0; k < this->_respiteMatrix[i][j].size(); k++){//boucle sur le nbr d'�tats d�puisement
				for(unsigned int l = 0; l < this->_respiteMatrix[i][j][k].size(); l++){
                    cout<<this->_respiteMatrix[i][j][k][l]<<" ";
				    }
				cout<<endl;
				}
		       cout<<"-----------------time-------------time"<<endl;
			}
		cout<<" ######################  cluster ####################################"<<endl;
		}



	   cout<<"------------------------------------------------------------------------"<<endl;
	   cout<<"le vecteur du burnout est le suivant : "<<endl;
	   cout<<"------------------------------------------------------------------------"<<endl;

	   for(unsigned int i = 0; i < this->_burnoutVector.size(); i++){
		   for(unsigned int j = 0; j < this->_burnoutVector[i].size(); j++){
			   for(unsigned int k = 0; k < this->_burnoutVector[i][j].size(); k++){
				   cout<<this->_burnoutVector[i][j][k]<<endl;
			   }

			   cout<<"------------------------Time--------------------"<<endl;
		   }
		   cout<<"-------------------Cluster--------------------"<<endl;
	   }



//	   cout<<"------------------------------------------------------------------------"<<endl;
//	   cout<<"le vecteur de fr�quence de r�pit est le suivant : "<<endl;
//	   cout<<"------------------------------------------------------------------------"<<endl;
//
//	   for(unsigned int i = 0; i < this->_respiteFrequenceVector.size(); i++){
//		   for(unsigned int j = 0; j < this->_respiteFrequenceVector[i].size(); j++){
//				   cout<<this->_respiteFrequenceVector[i][j]<<endl;
//		  cout<<"------------------------State--------------------"<<endl;
//		   }
//		   cout<<"-------------------Cluster--------------------"<<endl;
//	   }
//


	   cout<<"------------------------------------------------------------------------"<<endl;
	   cout<<"le vecteur du r�pit est le suivant : "<<endl;
	   cout<<"------------------------------------------------------------------------"<<endl;

	   for(unsigned int i = 0; i < this->_respiteVector.size(); i++){
		   for(unsigned int j = 0; j < this->_respiteVector[i].size(); j++){
			   for(unsigned int k = 0; k < this->_respiteVector[i][j].size(); k++){
				   cout<<this->_respiteVector[i][j][k]<<endl;
			   }

			   cout<<"------------------------Time--------------------"<<endl;
		   }
		   cout<<"-------------------Cluster--------------------"<<endl;
	   }
//
	}
//-----------------------------------------------------Fin----------------------------------



//-----------------------------------------------------Debut----------------------------------

void MarkovProcessAnalytic::genrateBurnoutRepartition(){

	vector< float> temp1(this->_inputData->getNbrStatePerCluster(), 0);

	for(unsigned int i = 0; i < this->_inputData->getNemberCluster(); i++){
		vector< vector <float> > temp2;
		for(unsigned int j = 0; j < this->_inputData->getTImeHorizon(); j++){
			vector< float> temp1(this->_inputData->getNbrStatePerCluster(), 0);
			for(unsigned int k = 0; k < this->_inputData->getNbrCaregiverPerCluster(); k++){
				if(j == 0){
					float burnout = this->_inputData->getBurnoutByIdByTime(i,k,j);
                    cout<<"mon burnout : "<<burnout<<endl;
					temp1[int(burnout)-1]+=float(1)/float(this->_inputData->getNbrCaregiverPerCluster());
					//cout<<"check mo, vector : "<<temp1[int(burnout)]<<endl;
				}

			}
			temp2.push_back(temp1);
		}
	  this->_burnoutVector.push_back(temp2);
	}
}
//-----------------------------------------------------Fin----------------------------------

//-----------------------------------------------------Debut----------------------------------

void MarkovProcessAnalytic::generateRespiteRepartition(){

	vector< float> temp1(this->_inputData->getmaxTimeInRespite(), 0);
	cout<<"mon r�pit vaut : "<<temp1[2]<<endl;
	vector< vector < float> > temp2 (this->_inputData->getNbrStatePerCluster(), temp1);

	for(unsigned int i = 0; i < this->_inputData->getNemberCluster(); i++){
		this->_respiteVector.push_back(temp2);
	}
	//vector< vector < vector< float> >  > this->_respiteVector(this->_inputData->getNemberCluster(), temp2);

}
//-----------------------------------------------------Fin----------------------------------


//-----------------------------------------------------Debut----------------------------------
void MarkovProcessAnalytic::generateVectorRespiteFrequence(){
		for(unsigned int j = 0; j < this->_inputData->getNemberCluster(); j++){
			vector<float>temp1;
			for(unsigned int k = 0; k < this->_inputData->getNbrStatePerCluster(); k++){
				if(k < this->_inputData->getNbrStatePerCluster()/2){
					float val = this->_respiteFrequence/2;
					val= val /float(this->_inputData->getmaxTimeInRespite()*(k+1));
					temp1.push_back(val);
				}
				else{
					float val = this->_respiteFrequence;
					val= val /float(this->_inputData->getmaxTimeInRespite()*(k+1));
					temp1.push_back(val);
				}
			}
			this->_respiteFrequenceVector.push_back(temp1);
		}
}
//-----------------------------------------------------Fin---------------------------------

//-----------------------------------------------------Debut----------------------------------
void MarkovProcessAnalytic::checkMarkovMatrix(){

	//Verfier les conditions stochastique de notre matice des transisons d eMarkov
	for(unsigned int i = 0; i < this->_burnoutMatrix.size(); i++){
		for(unsigned int j = 0; j < this->_burnoutMatrix[i].size(); j++){
			for(unsigned int k = 0; k < this->_burnoutMatrix[i][j].size(); k++){
				float val = 0;
				for(unsigned int l = 0; l < this->_respiteMatrix[i][j][k].size()+this->_burnoutMatrix[i][j][k].size(); l++){
					if(l < this->_respiteMatrix[i][j][k].size()){
						val+=this->_respiteMatrix[i][j][k][l];
					}
					else{
						val+=this->_burnoutMatrix[i][j][k][l-this->_respiteMatrix[i][j][k].size()];
					}
				}
				if(val != 1){
					cout<<" Attention la somme des probas sur une ligne est !!!!!!!!!!!!!!! : "<<val<<endl;
				}

			}
		}
	}

	//verifier les condition stochastique des vecteurs de r�partitons sur l'�puisement et le r�pit

	for(unsigned int i = 0; i < this->_inputData->getNemberCluster(); i++){
        float val = 0;
		for(unsigned int j = 0; j < this->_inputData->getNbrStatePerCluster(); j++){
			for(unsigned int k = 0; k < this->_inputData->getTImeHorizon() + this->_timeMaxRespite; k++){
				if(k < this->_inputData->getTImeHorizon()){
					val+=this->_burnoutVector[i][k][j];
				}
				else{
					val+=this->_respiteVector[i][j][k - this->_inputData->getTImeHorizon()];
				}
			}
		}
	     if (val != 1 ){
	    	 cout<<"Attention voila somme de ma r�partition !!!!!!!!!!!!!!!!!!! : "<<float(val)<<endl;
	     }


	}



}
//-----------------------------------------------------Fin---------------------------------

//-----------------------------------------------------Debut----------------------------------
void MarkovProcessAnalytic::stationnaryPolicy(){

	//this->_nbrIterationForMarkoProcess = this->_inputData->getTImeHorizon()*this->_inputData->getNbrStatePerCluster()
	for(unsigned int i = 0; i < 2000; i++){
		cout<<"############################################"<<endl;
		cout<<"------------Iteration --------------- : "<<i+1<<"--------"<<endl;
		cout<<"###########################################"<<endl;
		//this->printInstance();
		this->updateBurnoutVector();
		this->updateRespiteVector();
		this->_burnoutVector = burnoutTemp;
		this->_respiteVector = respiteTemp;
		//this->checkMarkovMatrix();
	}
}
//-----------------------------------------------------Fin----------------------------------

//-----------------------------------------------------Debut----------------------------------
void MarkovProcessAnalytic::updateBurnoutVector(){



burnoutTemp = this->_burnoutVector;
	for(unsigned int i = 0; i < this->_inputData->getNemberCluster(); i++){
		for(unsigned int j = 0; j < this->_inputData->getTImeHorizon(); j++){
			for(unsigned int k = 0; k < this->_inputData->getNbrStatePerCluster(); k++){
				float val = 0;
					if(j == 0){
						val = this->_respiteVector[i][k][0];
					}
					else{
						for(unsigned int l = 0; l < this->_inputData->getNbrStatePerCluster(); l++){
//							cout<<"la valeur du vecteur est : "<< this->_burnoutVector[i][j][l]<<endl;
//							cout<<"la valeur de la matrice est : "<< this->_burnoutMatrix[i][j-1][l][k]<<endl;
							val+=this->_burnoutVector[i][j-1][l]*this->_burnoutMatrix[i][j-1][l][k];
						}
					}
					burnoutTemp[i][j][k] = val;
			}
		}
	}

//	cout<<"voici le r�sultat du vecteur �puisement pour v�rifier"<<endl;
//	for(unsigned int i = 0; i < burnoutTemp.size(); i++){
//		for(unsigned int j = 0; j < burnoutTemp[i].size(); j++){
//			for(unsigned int k = 0; k < burnoutTemp[i][j].size(); k++){
//				cout<<burnoutTemp[i][j][k]<<endl;
//			}
//			cout<<"------------------time-----------------------"<<endl;
//		}
//		cout<<"------------------Cluster-----------------------"<<endl;
//	}
//


}
//-----------------------------------------------------Fin----------------------------------

//-----------------------------------------------------Debut----------------------------------
void MarkovProcessAnalytic::updateRespiteVector(){

	respiteTemp = this->_respiteVector;
	for(unsigned int i = 0; i < this->_inputData->getNemberCluster(); i++){
		for(unsigned int j = 0; j < this->_inputData->getNbrStatePerCluster(); j++){
			for(unsigned int k = 0; k < this->_inputData->getmaxTimeInRespite(); k++){
				float val = 0;
				for(unsigned int l = 0; l < this->_inputData->getTImeHorizon(); l++){
					unsigned int s = j;
					while(s < this->_inputData->getNbrStatePerCluster()){
						val +=this->_respiteMatrix[i][l][s][j]*this->_burnoutVector[i][l][s];
						s++;
					}
				}
				if(k < this->_inputData->getmaxTimeInRespite()-1){
					val+=this->_respiteVector[i][j][k+1];
				}
				respiteTemp[i][j][k] = val;
			}
		}
	}

//	cout<<"voici le r�sultat du vecteur r�pit pour v�rifier"<<endl;
//	for(unsigned int i = 0; i < respiteTemp.size(); i++){
//		for(unsigned int j = 0; j < respiteTemp[i].size(); j++){
//			for(unsigned int k = 0; k < respiteTemp[i][j].size(); k++){
//				cout<<respiteTemp[i][j][k]<<endl;
//			}
//			cout<<"------------------time-----------------------"<<endl;
//		}
//		cout<<"------------------Cluster-----------------------"<<endl;
//	}

}
//-----------------------------------------------------Fin----------------------------------

//-----------------------------------------------------Debut----------------------------------
void MarkovProcessAnalytic::getKpiResults(){

	vector<float> temp(this->_inputData->getTImeHorizon(), 0);
	for (unsigned int i = 0; i < this->_burnoutVector.size(); i++){
		for(unsigned int j = 0; j < this->_burnoutVector[i].size(); j++){
			for(unsigned int k = 0; k < this->_burnoutVector[i][j].size(); k++){
                if(k == this->_burnoutVector[i][j].size()-1){
                	temp[j]+=this->_burnoutVector[i][j][k];
                }

			}
		}
	}


	string const monFichier("C:/Users/Oussama BATATA/workspace/simulation/resultsMarkovProcess.txt");


	ofstream monflux(monFichier.c_str());

	for(unsigned int i = 0; i < temp.size(); i++){
   	 monflux<<temp[i]<<" ";
	}
//    float val = 0;
//	for (unsigned int i = 0; i < this->_burnoutVector.size(); i++){
//		for(unsigned int j = 0; j < this->_burnoutVector[i].size(); j++){
//
//			for(unsigned int k = 0; k < this->_burnoutVector[i][j].size(); k++){
//				cout<<_burnoutVector[i][j][k]<<"  ";
//                if (j == this->_burnoutVector[i].size()-1 && k <= this->_burnoutVector[i][j].size()-2){
//                	val+=this->_burnoutVector[i][j][k];
//                }
//                if(k == this->_burnoutVector[i][j].size()-1){
//                	 monflux<<this->_burnoutVector[i][j][k]<<" ";
//                }
//
//			}
//		}
//	}




//    	for (unsigned int i = 0; i < this->_respiteVector.size(); i++){
//    		for(unsigned int j = 0; j < this->_respiteVector[i].size(); j++){
//
//    			for(unsigned int k = 0; k < this->_respiteVector[i][j].size(); k++){
//    				cout<<_burnoutVector[i][j][k]<<"  ";
//
//    			}
//    			cout<<endl;
//    		}
//    	}


}
//-----------------------------------------------------Fin----------------------------------

} /* namespace mySpace */
