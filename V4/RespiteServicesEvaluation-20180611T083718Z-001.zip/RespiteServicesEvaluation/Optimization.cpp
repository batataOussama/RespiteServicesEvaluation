/*
 * Optimization.cpp
 *
 *  Created on: 8 juin 2018
 *      Author: oussama.batata
 */


#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include "InputData.h"
#include "Caregiver.h"
#include "caregiversPopulation.h"
#include "RespiteService.h"
#include "MarkovProcessAnalytic.h"


using namespace std;


#include "Optimization.h"

namespace mySpace {

vector< vector<float> > solVoisine;
float evalSolVoisine;

double randomUniformOpt()
{
	return rand()/(double)RAND_MAX;
}

double randomUniformOpt(double a,double b)
{
	return (b-a)*randomUniformm()+a;
}



//-----------------------------------------------------Debut----------------------------------

void Optimization::generateInitialRespiteFrequence(){


	for(unsigned int j = 0; j < this->_inputData->getNemberCluster(); j++){
		vector<float>temp1;
		for(unsigned int k = 0; k < this->_inputData->getNbrStatePerCluster(); k++){
            temp1.push_back(float(0.13)/float(this->_inputData->getmaxTimeInRespite()*(k+1)));
		}
		this->_respiteFrequenceVector.push_back(temp1);
	}

}

//-----------------------------------------------------Fin----------------------------------


//-----------------------------------------------------Debut----------------------------------
void Optimization::evaluateRespiteFrequence(){

	MarkovProcessAnalytic markovProcessAnalytic(this->_inputData, this->_respiteFrequenceVector);
    bool valChoose = 0;
    markovProcessAnalytic.generateInstance(valChoose);
    markovProcessAnalytic.printInstance();
    markovProcessAnalytic.stationnaryPolicy();
    //markovProcessAnalytic.printInstance();
    this->_evaluation = markovProcessAnalytic.getNbHospitalization();
    float respiteRessources = markovProcessAnalytic.getRespiteRessources();

    cout<<"nbHospitalization : "<<this->_evaluation<<endl;
    cout<<"nbRespiteRessources : "<<respiteRessources<<endl;
}
//-----------------------------------------------------Fin----------------------------------




//-----------------------------------------------------Debut----------------------------------

void Optimization::findNeighbor(unsigned int &idCluster, unsigned int &state){

	if (solVoisine[idCluster][state] < 0.9){
        solVoisine[idCluster][state]+=0.1;
	}

}

//-----------------------------------------------------Fin----------------------------------


//-----------------------------------------------------Debut----------------------------------

void Optimization::localSearch(){

    unsigned int idCluster = round(randomUniformOpt(0, this->_inputData->getNemberCluster()));
    unsigned int state = round(randomUniformOpt(0, this->_inputData->getNbrStatePerCluster()));
    solVoisine = this->_respiteFrequenceVector;
    evalSolVoisine = this->_evaluation;
    for (unsigned int i = 0; i < this->_inputData->getNemberCluster(); i++){
    	for(unsigned int j = 0; j < this->_inputData->getNbrStatePerCluster(); j++){
            this->findNeighbor(i, j);
            this->evaluateRespiteFrequence();
            if(this->_evaluation < evalSolVoisine){
            	solVoisine = this->_respiteFrequenceVector;
            	evalSolVoisine = this->_evaluation;
            }
    	}
    }



}

//-----------------------------------------------------Fin----------------------------------


//-----------------------------------------------------Debut----------------------------------

void Optimization::optimize(){


	this->generateInitialRespiteFrequence();
	this->evaluateRespiteFrequence();
//	for(unsigned int i = 0; i < this->_respiteFrequenceVector.size(); i++){
//
//		for(unsigned int j = 0; j < this->_respiteFrequenceVector[i]; j++){
//
//
//		}
//	}

}

//-----------------------------------------------------Fin----------------------------------



} /* namespace mySpace */
