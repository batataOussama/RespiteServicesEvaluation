/*
 * Optimization.h
 *
 *  Created on: 8 juin 2018
 *      Author: oussama.batata
 */

#ifndef OPTIMIZATION_H_
#define OPTIMIZATION_H_


#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include "InputData.h"
#include "Caregiver.h"
#include "caregiversPopulation.h"
#include "RespiteService.h"
#include "MarkovProcessAnalytic.h"


using namespace std;


namespace mySpace {

class Optimization {

private:

	vector < vector <float> > _respiteFrequenceVector;//vecteur fr�quence r�pit qu'on veut optimiser
    float _evaluation; // l'�valuation de notre vecteur de fr�quence r�pit



	//Pointeurs
	InputData *_inputData; //pointeur vers la class inputDatat pour r�cuperer des don�es
	MarkovProcessAnalytic *_markovProcessAnalytic; //pointeur vers la class MarkovProcesAnalytic pour l'optimiser


public:

	//constructeur ;
	Optimization(InputData *inputData, MarkovProcessAnalytic *markovProcessAnalytic);

      void generateInitialRespiteFrequence(); //pour trouver la solution initial(fr�quence de r�pitinitial) de notre optim
      void evaluateRespiteFrequence(); // pour evaluer la solution (fr�quence de r�pit)
      void findNeighbor(unsigned int &idCluster, unsigned int &state); // explorer la structure de voisugn
      void optimize(); //la fonction qui lance l'optimisation
      void localSearch();

};

inline Optimization::Optimization(InputData *inputData, MarkovProcessAnalytic *markovProcessAnalytic): _evaluation(0) {this->_inputData = inputData; this->_markovProcessAnalytic = markovProcessAnalytic;}

} /* namespace mySpace */

#endif /* OPTIMIZATION_H_ */
